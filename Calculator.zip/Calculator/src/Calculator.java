import javax.accessibility.AccessibleEditableText;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator extends JFrame {
    public int res = 0;

    public Calculator() {
        setTitle("Calculator");
        JPanel panel = new JPanel();
        JLabel a = new JLabel(" Enter the first number. ");
        JTextField x1 = new JTextField ("",2);
        JTextField x2 = new JTextField("",2);
        JLabel b = new JLabel(" Enter the second number. ");
        JButton plus = new JButton("+");
        JButton minus = new JButton("-");
        JButton multiply = new JButton("*");
        JButton divide = new JButton("/");
        JLabel c = new JLabel(" = ");
        JLabel result = new JLabel("");
        ActionListener listenerPlus = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x_1 = Integer.parseInt(x1.getText());
                {
                    if (x_1 <= 10 && x_1 >= 1) ;
                    else System.exit(0);
                }
                int x_2 = Integer.parseInt(x2.getText());
                {
                    if (x_2 <= 10 && x_2 >= 1) ;
                    else System.exit(0);
                }
                res = x_1 + x_2;
                result.setText(String.valueOf(res));
            }

            ;


        };
        ActionListener listenerminus = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x_1 = Integer.parseInt(x1.getText());
                {
                    if (x_1 <= 10 && x_1 >= 1) ;
                    else System.exit(0);
                }
                int x_2 = Integer.parseInt(x2.getText());
                {
                    if (x_2 <= 10 && x_2 >= 1) ;
                    else System.exit(0);
                }

                res = x_1 - x_2;
                result.setText(String.valueOf(res));
            }

            ;

        };
        ActionListener listenermultiply = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x_1 = Integer.parseInt(x1.getText());
                {
                    if (x_1 <= 10 && x_1 >= 1) ;
                    else System.exit(0);
                }
                int x_2 = Integer.parseInt(x2.getText());
                {
                    if (x_2 <= 10 && x_2 >= 1) ;
                    else System.exit(0);
                }
                               res = x_1 * x_2;
                result.setText(String.valueOf(res));
            }

            ;

        };
        ActionListener listenerdivide = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x_1 = Integer.parseInt(x1.getText());
                {
                    if (x_1 <= 10 && x_1 >= 1) ;
                    else System.exit(0);
                }
                int x_2 = Integer.parseInt(x2.getText());
                {
                    if (x_2 <= 10 && x_2 >= 1) ;
                    else System.exit(0);
                }

                res = x_1 / x_2;
                result.setText(String.valueOf(res));
            }
        };
        plus.addActionListener(listenerPlus);
        minus.addActionListener(listenerminus);
        multiply.addActionListener(listenermultiply);
        divide.addActionListener(listenerdivide);
        panel.setSize(new Dimension(100, 100));
        add(panel);
        panel.add(a);
        panel.add(x1);
        panel.add(b);
        panel.add(x2);
        panel.add(plus);
        panel.add(minus);
        panel.add(multiply);
        panel.add(divide);
        panel.add(c);
        panel.add(result);
        setPreferredSize(new Dimension(230, 230));
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }

    ;
}

